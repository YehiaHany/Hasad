class AppStrings {
  static const String bigHeadline = "اكتشف جودة الطعام معنا ";
  static const String searchPlants = "بحث";
}
