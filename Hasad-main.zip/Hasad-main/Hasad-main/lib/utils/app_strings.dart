class AppStrings {
  static const String bigHeadline = "أفضل المحاصيل و بأعلي جوده ";
  static const String searchPlants = "بحث";
}
